//
//  ViewController.swift
//  ProjectGroup
//
//  Created by student on 8/11/2562 BE.
//  Copyright © 2562 student. All rights reserved.
//

import UIKit

var gender = ""
class ViewController: UIViewController {
    
    @IBAction func view(_ sender: Any) {
        gender = "Male"
    }
    
    
    @IBAction func Viewf(_ sender: Any) {
        gender = "Female"
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

